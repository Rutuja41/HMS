export class LoginResponse {
    message:String="";
    role:String="";
}
