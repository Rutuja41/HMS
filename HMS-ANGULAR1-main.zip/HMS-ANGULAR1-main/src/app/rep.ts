export class Rep {
    id!: number;
    name:String="";
    email:String="";
    phone:String="";
    password:String="";
    gender:String="";
    age!:number;
    address:string="";
    city:string="";

}
