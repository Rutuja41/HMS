export class Patient {
    
    id!: number;
    name:String="";
    email:String="";
    password:String="";
    age!: number;
    gender:String="";
    phone: String="";
    address:String="";
      City:String="";
  
}
