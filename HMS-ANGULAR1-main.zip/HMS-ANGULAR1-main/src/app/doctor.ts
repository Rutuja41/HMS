export class Doctor {
    id!: number;
    name:String="";
    email:String="";
    age!:number;
    gender:String="";
    city:String="";
    address:String="";
    password:String="";
    phone!:number;
    specialization:String="";
}
